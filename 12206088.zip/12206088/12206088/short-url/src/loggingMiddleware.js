const logEndpoint = "http://localhost:5000/logs";

const Log = async (stack, level, packageName, message) => {
  const log = {
    stack,
    level,
    package: packageName,
    message,
    timestamp: new Date().toISOString(),
    userAgent: navigator.userAgent,
    url: window.location.href,
  };
  try {
    await fetch(logEndpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(log),
    });
  } catch (err) {
    console.error("Log failed:", err);
  }
};
export default Log;