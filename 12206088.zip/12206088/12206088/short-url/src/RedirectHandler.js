import Log from "./loggingMiddleware";
import { useEffect,useParams } from "react";
import { useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";
import {   Container, Typography,  Card, CardContent, Box } from "@mui/material";
const RedirectHandler = ({saveToStorage,getFromStorage}) => {
  const { shortcode } = useParams();
  const navigate = useNavigate();

  const urls = getFromStorage();
  useEffect(() => {
    const urlData = urls.find((u) => u.shortcode === shortcode);

    if (!urlData) {
      Log(
        "frontend",
        "error",
        "RedirectHandler",
        `Shortcode not found: ${shortcode}`
      );
      return;
    }

    const now = new Date();
    const expiry = new Date(urlData.expiresAt);
    if (now > expiry) {
      Log(
        "frontend",
        "error",
        "RedirectHandler",
        `Shortcode expired: ${shortcode}`
      );
      return;
    }

    urlData.clicks.push({
      timestamp: now.toISOString(),
      source: document.referrer,
      location: "India",
    });

    saveToStorage(urls);
    Log("frontend", "info", "RedirectHandler", `Redirecting: ${shortcode}`);
    window.location.href = urlData.originalUrl;
  }, [shortcode,navigate,getFromStorage,saveToStorage,urls]);

  return (
    <Container>
      <Typography variant="h4" gutterBottom>Statistics</Typography>
      {urls.map((url, i) => (
        <Card key={i} sx={{ mb: 3 }}>
          <CardContent>
            <Typography variant="h6">{window.location.origin}/{url.shortcode}</Typography>
            <Typography>Original: {url.originalUrl}</Typography>
            <Typography>Created: {url.createdAt}</Typography>
            <Typography>Expires: {url.expiresAt}</Typography>
            <Typography>Clicks: {url.clicks.length}</Typography>
            <Box mt={2}>
              {url.clicks.map((click, j) => (
                <Box key={j} sx={{ mb: 1 }}>
                  <Typography variant="body2">Time: {click.timestamp}</Typography>
                  <Typography variant="body2">Source: {click.source || "Direct"}</Typography>
                  <Typography variant="body2">Location: {click.location}</Typography>
                </Box>
              ))}
            </Box>
          </CardContent>
        </Card>
      ))}
      <Link to="/">Back to Shortener</Link>
    </Container>
  );
};

export default RedirectHandler;