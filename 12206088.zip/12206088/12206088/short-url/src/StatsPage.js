import { Link } from "react-router-dom";
import {  Container, Typography,  Card, CardContent, Box } from "@mui/material";
const StatsPage = ({getFromStorage}) => {
  const urls = getFromStorage();

  return (
     <Container>
      <Typography variant="h4" gutterBottom>Statistics</Typography>
      {urls.map((url, i) => (
        <Card key={i} sx={{ mb: 3 }}>
          <CardContent>
            <Typography variant="h6">{window.location.origin}/{url.shortcode}</Typography>
            <Typography>Original: {url.originalUrl}</Typography>
            <Typography>Created: {url.createdAt}</Typography>
            <Typography>Expires: {url.expiresAt}</Typography>
            <Typography>Clicks: {url.clicks.length}</Typography>
            <Box mt={2}>
              {url.clicks.map((click, j) => (
                <Box key={j} sx={{ mb: 1 }}>
                  <Typography variant="body2">Time: {click.timestamp}</Typography>
                  <Typography variant="body2">Source: {click.source || "Direct"}</Typography>
                  <Typography variant="body2">Location: {click.location}</Typography>
                </Box>
              ))}
            </Box>
          </CardContent>
        </Card>
      ))}
      <Link to="/">Back to Shortener</Link>
    </Container>
  );
};
export default StatsPage;