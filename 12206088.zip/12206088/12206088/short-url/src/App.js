import StatsPage from "./StatsPage";
import RedirectHandler from "./RedirectHandler";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import ShortenForm from "./ShortenForm";

const storageKey = "shortenedURLs";

const saveToStorage = (data) => {
  localStorage.setItem(storageKey, JSON.stringify(data));
};

const getFromStorage = () => {
  const data = localStorage.getItem(storageKey);
  return data ? JSON.parse(data) : [];
};

const generateShortcode = () => {
  return Math.random().toString(36).substring(2, 8);
};

const App = () => (
  <Router>
    <Routes>
      <Route
        path="/"
        element={
          <ShortenForm
            getFromStorage={getFromStorage}
            generateShortcode={generateShortcode}
            saveToStorage={saveToStorage}
          />
        }
      />
      <Route
        path="/stats"
        element={<StatsPage getFromStorage={getFromStorage} />}
      />
      <Route
        path=":shortcode"
        element={
          <RedirectHandler
            saveToStorage={saveToStorage}
            getFromStorage={getFromStorage}
          />
        }
      />
    </Routes>
  </Router>
);

export default App;
