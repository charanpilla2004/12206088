import { Link } from "react-router-dom";
import { useState } from "react";
import Log from "./loggingMiddleware";
import { TextField, Button, Container, Typography,  Card, CardContent, Box } from "@mui/material";
const ShortenForm = ({getFromStorage,generateShortcode,saveToStorage}) => {
  const [inputs, setInputs] = useState([{ url: "", validity: "", shortcode: "" }]);
  const [results, setResults] = useState([]);

  const handleChange = (i, e) => {
    const newInputs = [...inputs];
    newInputs[i][e.target.name] = e.target.value;
    setInputs(newInputs);
  };

  const addField = () => {
    if (inputs.length < 5) {
      setInputs([...inputs, { url: "", validity: "", shortcode: "" }]);
    }
  };

  const handleSubmit = async () => {
    const urls = getFromStorage();
    const newResults = [];

    for (let input of inputs) {
      if (!input.url.startsWith("http")) {
        Log("frontend", "error", "ShortenForm", `Invalid URL: ${input.url}`);
        continue;
      }

      const shortcode = input.shortcode || generateShortcode();
      const exists = urls.some((u) => u.shortcode === shortcode);

      if (exists) {
        Log("frontend", "error", "ShortenForm", `Shortcode collision: ${shortcode}`);
        continue;
      }

      const now = new Date();
      const minutes = parseInt(input.validity) || 30;
      const expiresAt = new Date(now.getTime() + minutes * 60000);

      const entry = {
        originalUrl: input.url,
        shortcode,
        createdAt: now.toISOString(),
        expiresAt: expiresAt.toISOString(),
        clicks: [],
      };

      urls.push(entry);
      newResults.push(entry);
      Log("frontend", "info", "ShortenForm", `Short URL created: ${shortcode}`);
    }

    saveToStorage(urls);
    setResults(newResults);
  };

  return (
    <Container>
      <Typography variant="h4" gutterBottom>Create Short URLs</Typography>
      {inputs.map((input, i) => (
        <Box key={i} mb={2}>
          <TextField name="url" label="Long URL" fullWidth margin="normal" value={input.url} onChange={(e) => handleChange(i, e)} />
          <TextField name="validity" label="Validity (minutes)" fullWidth margin="normal" value={input.validity} onChange={(e) => handleChange(i, e)} />
          <TextField name="shortcode" label="Custom Shortcode (optional)" fullWidth margin="normal" value={input.shortcode} onChange={(e) => handleChange(i, e)} />
        </Box>
      ))}
      <Button onClick={addField} variant="outlined" disabled={inputs.length >= 5}>Add More</Button>
      <Button onClick={handleSubmit} variant="contained" sx={{ ml: 2 }}>Shorten</Button>
      <Box mt={4}>
        <Typography style={{marginBottom:'1rem'}} variant="h6">Results:</Typography>
        {results.map((r, i) => (
          <Card key={i} sx={{ mb: 2 }}>
            <CardContent>
              <Typography>Short URL: <a href={`/${r.shortcode}`}>{window.location.origin}/{r.shortcode}</a></Typography>
              <Typography>Expires At: {r.expiresAt}</Typography>
            </CardContent>
          </Card>
        ))}
      </Box>
        <Link to="/stats" style={{textDecoration:'none',border:'1px solid hsl(0,0%,80%)',borderRadius:'0.5rem',background:'black',color:'white',padding:'0.5rem'}}>Stats Page</Link>
    </Container>
  );
};
export default ShortenForm;